document.querySelectorAll('.dropdown-submenu > a').forEach(el => {
  el.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      const submenu = el.nextElementSibling;
      submenu.classList.toggle('show');
  });
});




// silder item
var swiper = new Swiper(".mySwiper", {
  slidesPerView: 5,
  spaceBetween: 30,
  loop: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

document.addEventListener('DOMContentLoaded', () => {
  console.log('Page loaded successfully!');

  const buttons = document.querySelectorAll('.btn');
  buttons.forEach(button => {
    button.addEventListener('click', () => {
      alert(`You clicked on ${button.textContent}`);
    });
  });
});
 

// going to the next page
document.getElementById('whatsapp-btn').addEventListener('click', () => {
  window.open('8459789902');
});

document.getElementById('instagram-btn').addEventListener('click', () => {
  window.open('https://www.instagram.com/YOUR_INSTAGRAM_USERNAME', '_blank');
});


function showWeightLossImage() {
  const imageContainer = document.getElementById('imageContainer');
  imageContainer.style.display = 'block';
}


function showContent(sectionId) {
  
  document.querySelectorAll('.content').forEach(content => {
      content.style.display = 'none';
  });

  
  document.getElementById(sectionId).style.display = 'flex';

  
  document.querySelectorAll('.tab').forEach(tab => {
      tab.classList.remove('active');
  });
  event.target.classList.add('active');
}


// testimonials

document.addEventListener("DOMContentLoaded", () => {
  const testimonials = document.querySelectorAll(".testimonial-card"); 
  const prevButton = document.querySelector(".carousel-navigation.left");
  const nextButton = document.querySelector(".carousel-navigation.right"); 
  let currentIndex = 4; // Tracks the currently visible testimonial index

  // Function to update the visible testimonials
  const updateCarousel = () => {
      testimonials.forEach((testimonial, index) => {
          // Show only the active testimonials
          if (index === currentIndex || index === currentIndex + 1) {
              testimonial.style.display = "block";
          } else {
              testimonial.style.display = "none";
          }
      });
  };

  // Event listener for the "Next" button
  nextButton.addEventListener("click", () => {
      currentIndex += 1;
      if (currentIndex >= testimonials.length - 1) {
          currentIndex = 1; // Reset to the beginning
      }
      updateCarousel();
  });

  // Event listener for the "Previous" button
  prevButton.addEventListener("click", () => {
      currentIndex -= 1;
      if (currentIndex < 0) {
          currentIndex = testimonials.length - 2; 
      }
      updateCarousel();
  });

  // Initialize the carousel
  updateCarousel();
});


document.addEventListener("DOMContentLoaded", () => {
  const swiper2 = new Swiper('.mySwiper2', {
    slidesPerView: 9, 
    spaceBetween: 20, 
    loop: true, 
    navigation: {
      nextEl: '.swiper2-button-next',
      prevEl: '.swiper2-button-prev',
    },
    autoplay: {
      delay: 1000, 
      disableOnInteraction: true, 
    },
    breakpoints: {
      640: {
        slidesPerView: 2,
        spaceBetween: 10,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 15,
      },
      1024: {
        slidesPerView: 9,
        spaceBetween: 20,
      },
    },
  });
});




  